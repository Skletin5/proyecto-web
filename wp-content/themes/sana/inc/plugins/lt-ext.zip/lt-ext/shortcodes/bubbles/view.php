<?php if ( ! defined( 'ABSPATH' ) ) die( 'Forbidden' );
/**
 * Bubbles Shortcode
 */

$args = get_query_var('like_sc_bubbles');

echo '<canvas id="ltx-bubbles"></canvas>';


